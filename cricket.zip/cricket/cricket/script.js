// Login Form Validation
document.getElementById('login-form').addEventListener('submit', function(event) {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
  
    if (username === "" || password === "") {
      alert("Both fields are required.");
      event.preventDefault();
    }
  });
  
  // Register Form Validation
  document.getElementById('register-form').addEventListener('submit', function(event) {
    const username = document.getElementById('register-username').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
  
    // Username validation (optional length check)
    if (username.length < 3) {
      alert("Username must be at least 3 characters long.");
      event.preventDefault();
      return;
    }
  
    // Email validation using a simple regex pattern
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
      alert("Please enter a valid email address.");
      event.preventDefault();
      return;
    }
  
    // Password validation
    if (password.length < 6) {
      alert("Password must be at least 6 characters long.");
      event.preventDefault();
      return;
    }
  
    // Confirm Password validation
    if (password !== confirmPassword) {
      alert("Passwords do not match.");
      event.preventDefault();
      return;
    }
  });
  